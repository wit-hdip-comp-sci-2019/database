drop database if exists mysupplierdb;
create database mysupplierdb;
use mysupplierdb;
create table supplier (
supplierId int auto_increment,
fName varchar(15) not null,
lName varchar(20) not null,
phone char(15),
emailAddress varchar(30) not null,
location varchar(20),
primary key(supplierId)
);


create table product (
productCode char(6),
name varchar(30) not null,
description varchar(200),
price decimal(6,2) unsigned not null,
stockQuantity smallint unsigned not null,
colour varchar(20) not  null,
supplierId int,
primary key(productCode),
constraint fk_prod foreign key (supplierId) references supplier(supplierId)
on update cascade on delete set null
);

insert into supplier (fName, lName, phone, emailAddress, location) values
('Joe', 'Barry', '353513078990', 'jbarry@gmail.com', 'London'),
('Philip', 'Jones', '353879945321', 'philjones@gmail.com','Dublin'),
('Maria', 'Lacey', '353873345899', 'mlacey@gmail.com', 'Glasgow'),
('Jane', 'Barry', '35356667211', 'janebarry@gmail.com', 'London'),
('Tina', 'Cooney', '353878934133', 'tcooney@gmail.com', 'Dublin');

insert into product values
('p12345','SKECHERS FLEX APPEAL', 'The sleek, athletic design is loaded with extras, including memory foam cushioned insoles, a flexible, shock absorbing midsole and breathable mesh panels to keep your feet cool and dry.', 80.00, 730, 'White', 1),
('p12673','SKECHERS GLIDER HARMONY', 'The Skechers Womens Glider Harmony are the perfect trainer for the women on the go with their breathable mesh upper and pull on design.', 78.00, 129, 'Navy', 1),
('p13111','SKECHERS SKECH APPEAL', 'Cool, sporty and comfortable are the Skechers Skech Appeal. This shoe is perfect for your little ones with super soft skech-knit fabric and memory foam insole keeping them comfortable all day along.', 45.00, 289, 'Grey', 2),
('p13456','MUNSTER HOME JERSEY', 'The latest Munster Home Jersey designed by adidas epitomises the Red Army: loyal, brave and intimidating.', 70.00, 344, 'Red', null),
('p13567','MUNSTER EUROPEAN JERSEY', 'The Munster ERCC Jersey is deep red and navy. Devoted to heritage a checked theme throughout was inspired by the kit worn during their Heineken Cup victory in Cardiff in 2006.', 100.00, 78, 'Red',3),
('p13789','MUNSTER ALTERNATE JERSEY', 'The alternate jersey is navy with a striking yellow trim and celebrates the significance of the Munster stag, an animal which in Irish folklore is always portrayed as defending its own territory.', 70.00, 110, 'Navy', 2),
('p13890','MUNSTER EUROPEAN FLEECE', null, 75.00, 36, 'Red',3),
('p13900','MUNSTER EUROPEAN SOCKS', NULL, 15.00, 45, 'Navy', 2);
